"""campus.python.audit.v1.apikeys

Campus Audit API keys resource (v1).

API keys are the audit service's own auth material (audit_v1_...),
managed here: create, list, inspect, update, revoke, regenerate.
Plaintext key values are returned exactly once, at creation and at
regeneration.

A key's privilege set may be given as a scope list or as a named role
the service resolves to one (the catalogue is the service's, so it is
not duplicated here).

The service's catalogue (campus#918) currently holds:

    traces-viewer    traces:read
    traces-searcher  traces:read, traces:search
    traces-producer  traces:read, traces:search, traces:write
    key-operator     apikeys:read, apikeys:write

That list is quoted here for orientation, not as a contract: the
service is the authority, and it refuses an unknown role with the
names of the roles it does have. No role resolves to a wildcard.
"""

from ...interface import JsonDict, Resource, ResourceCollection, payload, updates


class APIKeys(ResourceCollection):
    """Campus Audit API keys resource.

    Every write takes a privilege set: either a scope list or a named
    role the service resolves to one.
    """
    path = "apikeys"

    def __getitem__(self, api_key_id: str) -> "APIKeys.APIKey":
        """Get a specific API key resource by ID."""
        return APIKeys.APIKey(api_key_id, parent=self)

    def new(
            self,
            *,
            name: str,
            owner_id: str,
            scopes: "list[str] | None" = None,
            role: "str | None" = None,
            rate_limit: "int | None" = None,
            expires_at: "str | None" = None,
    ) -> JsonDict:
        """Create an API key.

        Give either `scopes` or a named `role` — the service resolves a
        role to exactly one scope list. The two are mutually exclusive
        server-side: sending both is refused (422) rather than one
        silently winning, so this method does not pre-judge them. An
        unknown role is likewise refused, with the server naming the
        roles that exist — the catalogue is the service's, so it is not
        duplicated here.

        Args:
            name: Key name
            owner_id: Owner user ID
            scopes: Scope strings the key grants (e.g. ["traces:read"])
            role: A named role the service resolves to a scope list
            rate_limit: Requests per minute (optional)
            expires_at: ISO 8601 expiry (optional)

        Returns:
            The created key record; its plaintext `api_key` value is
            shown only here.
        """
        return self._post_json(self.make_path(), json=payload(
            name=name,
            owner_id=owner_id,
            scopes=scopes,
            role=role,
            rate_limit=rate_limit,
            expires_at=expires_at,
        ))

    def list(
            self,
            *,
            owner_id: "str | None" = None,
            active_only: bool = True,
            limit: "int | None" = None,
    ) -> JsonDict:
        """List API keys with optional filtering.

        Args:
            owner_id: Filter by owner user ID
            active_only: Only non-expired, non-revoked keys (default True)
            limit: Page size (server default 50)

        Returns:
            {"api_keys": [...], "count": int}
        """
        query: JsonDict = {}
        if owner_id is not None:
            query["owner_id"] = owner_id
        # The server parses bool query values from the lowercase
        # literals true/false (flask_campus _BOOL_LITERALS); Python's
        # str(True) capitalization would 422.
        query["active_only"] = str(active_only).lower()
        if limit is not None:
            query["limit"] = limit
        return self._get_json(self.make_path(), query=query)

    class APIKey(Resource):
        """Single campus audit API key resource.

        update() takes a privilege set too: a scope list or a named
        role.
        """

        def get(self) -> JsonDict:
            """Get this API key's record (no key hash or plaintext)."""
            return self._get_json(self.make_path(end_slash=True))

        def update(
                self,
                *,
                name: "str | None" = None,
                scopes: "list[str] | None" = None,
                role: "str | None" = None,
                rate_limit: "int | None" = None,
        ) -> JsonDict:
            """Update this API key's mutable fields.

            Only name, scopes, and rate_limit are mutable; use
            revoke() to disable the key. The server rejects an empty
            update, so at least one field must be provided.

            A `role` re-scopes the key to the scope list the service
            resolves that role to. It is mutually exclusive with
            `scopes` server-side: sending both is refused (422) rather
            than one silently winning, so this method does not
            pre-judge them.

            Returns:
                The updated key record
            """
            return self._patch_json(self.make_path(end_slash=True), json=updates(
                name=name,
                scopes=scopes,
                role=role,
                rate_limit=rate_limit,
            ))

        def revoke(self) -> None:
            """Revoke this API key (the record is kept for audit)."""
            self._delete_json(self.make_path(end_slash=True))
            return None

        def regenerate(self) -> str:
            """Regenerate this API key's value.

            The old value stops working immediately.

            Returns:
                The new plaintext key value, shown only here.
            """
            return self._post_json(
                self.make_path("regenerate", end_slash=False)
            )["key"]
