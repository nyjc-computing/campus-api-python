"""campus.python.auth.v1.clients

Campus Auth Clients resource (v1).
"""
from __future__ import annotations

import campus.model

from ...interface import JsonDict, Resource, ResourceCollection, payload


class Clients(ResourceCollection):
    """Campus Auth Clients resource."""
    path = "clients"

    def __getitem__(self, client_id: str) -> "Clients.Client":
        """Get a specific client resource by ID."""
        return Clients.Client(client_id, parent=self)

    def list(self) -> "list[campus.model.Client]":
        """List all OAuth clients.

        Returns:
            List of Client objects.
        """
        body = self._get_json(self.make_path())
        return [
            campus.model.Client.from_resource(item)
            for item in body["clients"]
        ]

    def new(
            self,
            name: str,
            description: str,
            is_public: bool = False,
            redirect_uris: list[str] | None = None,
            allowed_scopes: list[str] | None = None,
            upstream_scopes: dict[str, list[str]] | None = None,
            token_bridge: bool | None = None
    ) -> campus.model.Client:
        """Create a new client.

        Args:
            name: Client name
            description: Client description
            is_public: True for public clients (CLI/mobile apps) without secrets
            redirect_uris: OAuth redirect URIs for public clients
            allowed_scopes: Token-scope allowlist (fail-closed: an
                empty list grants nothing)
            upstream_scopes: Per-provider upstream scope map
                (e.g. {"google": [...]})
            token_bridge: Token bridge access flag (upstream token
                release; rejected by the server for public clients)

        Returns:
            The created Client
        """
        return campus.model.Client.from_resource(self._post_json(
            self.make_path(),
            json=payload(
                name=name,
                description=description,
                is_public=is_public,
                redirect_uris=redirect_uris or [],
                allowed_scopes=allowed_scopes,
                upstream_scopes=upstream_scopes,
                token_bridge=token_bridge,
            )
        ))

    class Client(Resource):
        """Campus Auth Client resource."""

        @property
        def access(self) -> "Clients.Client.ClientAccess":
            return Clients.Client.ClientAccess("access", parent=self)

        @property
        def client_id(self) -> str:
            """The client_id of the resource was passed in as a path
            parameter, and is extracted using this property alias.
            """
            return self.path.strip("/")

        def delete(self) -> None:
            """Delete this client."""
            self._delete_json(self.make_path())

        def get(self) -> campus.model.Client:
            """Get this client.

            Returns:
                The Client.
            """
            body = self._get_json(self.make_path())
            return campus.model.Client.from_resource(body)

        def revoke(self) -> str:
            """Revoke the client secret and return the new one.

            Returns:
                The newly generated client secret.
            """
            return self._post_json(self.make_path("revoke", end_slash=False))["secret"]

        def update(
                self,
                name: str | None = None,
                description: str | None = None,
                redirect_uris: list[str] | None = None,
                allowed_scopes: list[str] | None = None,
                upstream_scopes: dict[str, list[str]] | None = None,
                token_bridge: bool | None = None
        ) -> campus.model.Client:
            """Update the client.

            Only the fields passed are sent; the server replaces each
            provided field wholesale (PATCH semantics), so list and
            dict values must carry the full desired contents.

            Args:
                name: New client name
                description: New client description
                redirect_uris: New OAuth redirect URIs
                allowed_scopes: Replacement token-scope allowlist
                    (fail-closed: an empty list grants nothing)
                upstream_scopes: Replacement per-provider upstream
                    scope map (e.g. {"google": [...]})
                token_bridge: Token bridge access flag (rejected by the
                    server for public clients)

            Returns:
                The updated Client
            """
            return campus.model.Client.from_resource(self._patch_json(
                self.make_path(),
                json=payload(
                    name=name,
                    description=description,
                    redirect_uris=redirect_uris,
                    allowed_scopes=allowed_scopes,
                    upstream_scopes=upstream_scopes,
                    token_bridge=token_bridge,
                )
            ))

        class ClientAccess(Resource):
            """Campus Auth Client Access resource."""

            def get(
                    self,
                    vault: str | None = None
            ) -> JsonDict:
                """Get this client's vault access mapping.

                Args:
                    vault: Scope the mapping to one vault label.

                Returns:
                    {vault_label: permission} for the accessible vaults.
                """
                # GET rule is /<client_id>/access/ (trailing slash) and the
                # auth app sets strict_slashes — the slash is required.
                if vault:
                    return self._get_json(
                        self.make_path(end_slash=True),
                        query={"vault": vault}
                    )
                return self._get_json(self.make_path(end_slash=True))

            def check(
                    self,
                    vault: str,
                    permission: int,
            ) -> JsonDict:
                """Check whether the client holds a permission on a vault.

                GET /<client_id>/access/check?vault=&permission=
                Returns: {"vault": ..., "permission": <bool>}
                """
                return self._get_json(
                    self.make_path("check", end_slash=False),
                    query={"vault": vault, "permission": permission}
                )

            def grant(
                    self,
                    vault: str,
                    permission: int,
            ) -> JsonDict:
                """Grant this client a permission on a vault.

                Args:
                    vault: Vault label.
                    permission: Permission level to grant.

                Returns:
                    The resulting access record.
                """
                return self._post_json(self.make_path("grant", end_slash=False), json={
                    "vault": vault,
                    "permission": permission,
                })

            def revoke(
                    self,
                    vault: str,
                    permission: int,
            ) -> JsonDict:
                """Revoke this client's permission on a vault.

                Args:
                    vault: Vault label.
                    permission: Permission level to revoke.

                Returns:
                    The resulting access record.
                """
                return self._post_json(self.make_path("revoke", end_slash=False), json={
                    "vault": vault,
                    "permission": permission,
                })

            def update(
                    self,
                    vault: str,
                    permission: int,
            ) -> JsonDict:
                """Set this client's permission on a vault (upsert).

                PATCHes the access collection directly.

                Args:
                    vault: Vault label.
                    permission: Permission level to set.

                Returns:
                    The resulting access record.
                """
                return self._patch_json(self.make_path(end_slash=True), json={
                    "vault": vault,
                    "permission": permission,
                })
